import React from 'react';

import './Home.css';
import SlideView from './SlideView/SlideView';

const Home = () => {
  return (
    <div className="home">
      <SlideView />
      
    </div>
  );
}

export default Home;